import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  filmes = [
    { Titulo: 'A Jornada do Herói', Diretor: 'John Doe', Atores: ['Ator 1', 'Ator 2'], Generos: ['Ação', 'Aventura'] },
    { Titulo: 'O Mistério da Noite', Diretor: 'Jane Smith', Atores: ['Ator 3', 'Ator 4'], Generos: ['Mistério', 'Drama'] }
  ];

  constructor(public navCtrl: NavController, public alertCtrl: AlertController) {}

  showPrompt() {
    const prompt = this.alertCtrl.create({
      title: 'Adicionar Filme',
      message: "Insira os dados do filme:",
      inputs: [
        {
          name: 'Titulo',
          placeholder: 'Título do Filme',
          type: 'text'
        },
        {
          name: 'Diretor',
          placeholder: 'Diretor do Filme',
          type: 'text'
        },
        {
          name: 'Atores',
          placeholder: 'Atores (separados por vírgula)',
          type: 'text'
        },
        {
          name: 'Generos',
          placeholder: 'Gêneros (separados por vírgula)',
          type: 'text'
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Adicionar',
          handler: data => {
            if (data.Titulo && data.Diretor && data.Atores) {
              const atores = data.Atores.split(',').map(a => a.trim());
              const generos = data.Generos ? data.Generos.split(',').map(g => g.trim()) : [];
              const filme = { Titulo: data.Titulo, Diretor: data.Diretor, Atores: atores, Generos: generos };
              this.filmes.push(filme);
            } else {
              console.log('Preencha todos os campos obrigatórios');
            }
          }
        }
      ]
    });
    prompt.present();
  }

  excluir(filme) {
    console.log('Excluir', filme);

    for (let i = 0; i < this.filmes.length; i++) {
      const item = this.filmes[i];
      if (item.Titulo === filme.Titulo && item.Diretor === filme.Diretor) {
        this.filmes.splice(i, 1);
        break;
      }
    }
  }

  showConfirm(filme) {
    const confirm = this.alertCtrl.create({
      title: 'Excluir Filme',
      message: 'Deseja excluir este filme?',
      buttons: [
        {
          text: 'Cancelar',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Confirmar',
          handler: () => {
            this.excluir(filme);
          }
        }
      ]
    });
    confirm.present();
  }
}
