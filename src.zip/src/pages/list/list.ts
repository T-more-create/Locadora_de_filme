import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-list',
  templateUrl: 'list.html'
})
export class ListPage {
  selectedItem: any;
  items: Array<{ title: string, director: string, synopsis: string, icon: string }>;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');

    // Lista de filmes populares com ícones e descrições
    this.items = [
      { title: 'A Jornada do Herói', director: 'John Doe', synopsis: 'Um épico de aventura e coragem.', icon: 'film' },
      { title: 'O Mistério da Noite', director: 'Jane Smith', synopsis: 'Um suspense intrigante e envolvente.', icon: 'film' },
      { title: 'O Grande Gatsby', director: 'Baz Luhrmann', synopsis: 'A história de um sonho americano desfeito.', icon: 'film' },
      { title: 'Interstellar', director: 'Christopher Nolan', synopsis: 'Uma jornada intergaláctica em busca de um novo lar.', icon: 'film' },
      { title: 'A Origem', director: 'Christopher Nolan', synopsis: 'Um thriller psicológico sobre sonhos e realidade.', icon: 'film' },
      { title: 'Pulp Fiction', director: 'Quentin Tarantino', synopsis: 'Uma narrativa entrelaçada de histórias de crime.', icon: 'film' },
      { title: 'O Poderoso Chefão', director: 'Francis Ford Coppola', synopsis: 'A saga da família Corleone no mundo do crime.', icon: 'film' },
      { title: 'Forrest Gump', director: 'Robert Zemeckis', synopsis: 'A vida de um homem comum que influencia a história.', icon: 'film' },
      { title: 'A Rede Social', director: 'David Fincher', synopsis: 'A criação e ascensão do Facebook e seu impacto.', icon: 'film' },
      { title: 'Mad Max: Estrada da Fúria', director: 'George Miller', synopsis: 'Uma corrida frenética por um futuro apocalíptico.', icon: 'film' }
    ];
  }

  itemTapped(event, item) {
    // Navega para a página de detalhes (se existir)
    this.navCtrl.push(ListPage, {
      item: item
    });
  }
}
